'use client';

import Link from 'next/link';

export default function Navbar() {
  return (
    <nav className="bg-white shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Link href="/" className="flex-shrink-0 flex items-center">
              <span className="text-primary-color text-xl font-bold">Taiwan High Tea</span>
            </Link>
          </div>
          
          <div className="hidden md:flex md:items-center md:space-x-8">
            <Link href="/" className="text-text-dark hover:text-primary-color px-3 py-2 font-medium">
              Home
            </Link>
            <Link href="/about" className="text-text-dark hover:text-primary-color px-3 py-2 font-medium">
              About
            </Link>
            <Link href="/products" className="text-text-dark hover:text-primary-color px-3 py-2 font-medium">
              Products
            </Link>
            <Link href="/contact" className="text-text-dark hover:text-primary-color px-3 py-2 font-medium">
              Contact
            </Link>
            <Link href="/products" className="btn btn-primary ml-4">
              Shop Now
            </Link>
          </div>
          
          <div className="flex items-center md:hidden">
            <button className="text-gray-500 hover:text-gray-700 focus:outline-none">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </button>
          </div>
        </div>
      </div>
      
      {/* Mobile menu, show/hide based on menu state */}
      <div className="hidden md:hidden">
        <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
          <Link href="/" className="block px-3 py-2 rounded-md text-base font-medium text-text-dark hover:text-primary-color">
            Home
          </Link>
          <Link href="/about" className="block px-3 py-2 rounded-md text-base font-medium text-text-dark hover:text-primary-color">
            About
          </Link>
          <Link href="/products" className="block px-3 py-2 rounded-md text-base font-medium text-text-dark hover:text-primary-color">
            Products
          </Link>
          <Link href="/contact" className="block px-3 py-2 rounded-md text-base font-medium text-text-dark hover:text-primary-color">
            Contact
          </Link>
          <Link href="/products" className="block px-3 py-2 rounded-md text-base font-medium bg-primary-color text-white">
            Shop Now
          </Link>
        </div>
      </div>
    </nav>
  );
}
