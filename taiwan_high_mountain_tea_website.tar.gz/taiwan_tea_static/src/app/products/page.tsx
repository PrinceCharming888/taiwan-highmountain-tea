'use client';

export default function Products() {
  return (
    <div className="bg-white">
      {/* Hero Section */}
      <section className="relative h-[40vh] bg-green-50">
        <div className="absolute inset-0 bg-[url('/images/tea-plantation-landscape.jpg')] bg-cover bg-center">
          <div className="absolute inset-0 bg-black bg-opacity-40"></div>
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-full flex flex-col justify-center">
          <div className="text-center text-white">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">Our Products</h1>
            <p className="text-xl max-w-3xl mx-auto">
              Explore our selection of premium Taiwan high mountain teas
            </p>
          </div>
        </div>
      </section>

      {/* Product Listing */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center text-gray-800 mb-12">Alishan Tea Collection</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white border border-gray-200 rounded-lg overflow-hidden shadow-sm">
              <div className="h-64 bg-gray-200 relative">
                <div className="absolute inset-0 bg-[url('/images/tea-leaves-closeup.jpg')] bg-cover bg-center"></div>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-2 text-gray-800">Alishan Qing Xin Oolong</h3>
                <p className="text-gray-600 mb-4">
                  A classic high mountain oolong with a delicate floral aroma and smooth, sweet finish. Grown at an elevation of 1,200 meters in the misty Alishan mountain range, this tea exemplifies the refined character of Taiwan's high mountain teas.
                </p>
                <div className="flex justify-between items-center mb-4">
                  <div>
                    <p className="text-green-700 font-medium">$35.00</p>
                    <p className="text-gray-500 text-sm">150g / 5.3oz</p>
                  </div>
                  <button className="bg-green-700 hover:bg-green-800 text-white py-2 px-4 rounded-md">
                    Add to Cart
                  </button>
                </div>
                <div className="mt-4">
                  <h4 className="text-sm font-medium text-gray-800 mb-2">Tasting Notes:</h4>
                  <p className="text-gray-600 text-sm">Orchid, honey, fresh vegetation with a lingering sweet aftertaste</p>
                </div>
              </div>
            </div>
            
            <div className="bg-white border border-gray-200 rounded-lg overflow-hidden shadow-sm">
              <div className="h-64 bg-gray-200 relative">
                <div className="absolute inset-0 bg-[url('/images/tea-pouring.jpg')] bg-cover bg-center"></div>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-2 text-gray-800">Alishan Jin Xuan (Milk Oolong)</h3>
                <p className="text-gray-600 mb-4">
                  Known for its natural creamy flavor and silky texture with subtle milky notes. This Jin Xuan cultivar grown in the Alishan region develops a unique buttery character that makes it a favorite among tea enthusiasts worldwide.
                </p>
                <div className="flex justify-between items-center mb-4">
                  <div>
                    <p className="text-green-700 font-medium">$32.00</p>
                    <p className="text-gray-500 text-sm">150g / 5.3oz</p>
                  </div>
                  <button className="bg-green-700 hover:bg-green-800 text-white py-2 px-4 rounded-md">
                    Add to Cart
                  </button>
                </div>
                <div className="mt-4">
                  <h4 className="text-sm font-medium text-gray-800 mb-2">Tasting Notes:</h4>
                  <p className="text-gray-600 text-sm">Creamy, buttery, floral with a smooth, silky mouthfeel</p>
                </div>
              </div>
            </div>
            
            <div className="bg-white border border-gray-200 rounded-lg overflow-hidden shadow-sm">
              <div className="h-64 bg-gray-200 relative">
                <div className="absolute inset-0 bg-[url('/images/tea-plantation-landscape.jpg')] bg-cover bg-center"></div>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-2 text-gray-800">Alishan Black Tea</h3>
                <p className="text-gray-600 mb-4">
                  A rare fully-oxidized tea from Alishan with honey and fruit notes and a malty character. This unique black tea showcases how the high mountain terroir can create exceptional fully-oxidized teas with remarkable complexity.
                </p>
                <div className="flex justify-between items-center mb-4">
                  <div>
                    <p className="text-green-700 font-medium">$38.00</p>
                    <p className="text-gray-500 text-sm">150g / 5.3oz</p>
                  </div>
                  <button className="bg-green-700 hover:bg-green-800 text-white py-2 px-4 rounded-md">
                    Add to Cart
                  </button>
                </div>
                <div className="mt-4">
                  <h4 className="text-sm font-medium text-gray-800 mb-2">Tasting Notes:</h4>
                  <p className="text-gray-600 text-sm">Honey, stone fruit, malt with a smooth, clean finish</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Lishan Collection */}
      <section className="py-16 bg-green-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center text-gray-800 mb-12">Lishan Tea Collection</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white border border-gray-200 rounded-lg overflow-hidden shadow-sm">
              <div className="h-64 bg-gray-200 relative">
                <div className="absolute inset-0 bg-[url('/images/tea-leaves-closeup.jpg')] bg-cover bg-center"></div>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-2 text-gray-800">Lishan Qing Xin Oolong</h3>
                <p className="text-gray-600 mb-4">
                  Premium high mountain oolong with a complex floral aroma and sweet, lingering finish. Grown at elevations above 1,800 meters, this tea represents the pinnacle of Taiwan's high mountain oolong tradition.
                </p>
                <div className="flex justify-between items-center mb-4">
                  <div>
                    <p className="text-green-700 font-medium">$45.00</p>
                    <p className="text-gray-500 text-sm">150g / 5.3oz</p>
                  </div>
                  <button className="bg-green-700 hover:bg-green-800 text-white py-2 px-4 rounded-md">
                    Add to Cart
                  </button>
                </div>
                <div className="mt-4">
                  <h4 className="text-sm font-medium text-gray-800 mb-2">Tasting Notes:</h4>
                  <p className="text-gray-600 text-sm">Complex floral bouquet, honey sweetness, mineral undertones</p>
                </div>
              </div>
            </div>
            
            <div className="bg-white border border-gray-200 rounded-lg overflow-hidden shadow-sm">
              <div className="h-64 bg-gray-200 relative">
                <div className="absolute inset-0 bg-[url('/images/tea-pouring.jpg')] bg-cover bg-center"></div>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-2 text-gray-800">Lishan Spring Harvest</h3>
                <p className="text-gray-600 mb-4">
                  Limited edition spring harvest with vibrant floral notes and exceptional clarity. The spring harvest is particularly prized for its fresh, vibrant character and pronounced aromatics.
                </p>
                <div className="flex justify-between items-center mb-4">
                  <div>
                    <p className="text-green-700 font-medium">$52.00</p>
                    <p className="text-gray-500 text-sm">150g / 5.3oz</p>
                  </div>
                  <button className="bg-green-700 hover:bg-green-800 text-white py-2 px-4 rounded-md">
                    Add to Cart
                  </button>
                </div>
                <div className="mt-4">
                  <h4 className="text-sm font-medium text-gray-800 mb-2">Tasting Notes:</h4>
                  <p className="text-gray-600 text-sm">Vibrant florals, fresh spring vegetation, crystalline clarity</p>
                </div>
              </div>
            </div>
            
            <div className="bg-white border border-gray-200 rounded-lg overflow-hidden shadow-sm">
              <div className="h-64 bg-gray-200 relative">
                <div className="absolute inset-0 bg-[url('/images/tea-plantation-landscape.jpg')] bg-cover bg-center"></div>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-2 text-gray-800">Aged Lishan Oolong</h3>
                <p className="text-gray-600 mb-4">
                  Carefully aged for 5 years to develop deeper complexity, with notes of honey and dried fruit. Aging transforms the tea's character, mellowing certain notes while developing new dimensions of flavor.
                </p>
                <div className="flex justify-between items-center mb-4">
                  <div>
                    <p className="text-green-700 font-medium">$60.00</p>
                    <p className="text-gray-500 text-sm">150g / 5.3oz</p>
                  </div>
                  <button className="bg-green-700 hover:bg-green-800 text-white py-2 px-4 rounded-md">
                    Add to Cart
                  </button>
                </div>
                <div className="mt-4">
                  <h4 className="text-sm font-medium text-gray-800 mb-2">Tasting Notes:</h4>
                  <p className="text-gray-600 text-sm">Dried fruit, honey, wood, with a smooth, deep character</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Premium Collection */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center text-gray-800 mb-12">Premium Collection</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white border border-gray-200 rounded-lg overflow-hidden shadow-sm">
              <div className="h-64 bg-gray-200 relative">
                <div className="absolute inset-0 bg-[url('/images/tea-leaves-closeup.jpg')] bg-cover bg-center"></div>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-2 text-gray-800">Dayuling High Mountain Oolong</h3>
                <p className="text-gray-600 mb-4">
                  The most prestigious Taiwanese tea, grown at elevations above 2,200 meters with exceptional complexity. Dayuling represents the pinnacle of Taiwan's high mountain teas, with limited production and extraordinary character.
                </p>
                <div className="flex justify-between items-center mb-4">
                  <div>
                    <p className="text-green-700 font-medium">$65.00</p>
                    <p className="text-gray-500 text-sm">150g / 5.3oz</p>
                  </div>
                  <button className="bg-green-700 hover:bg-green-800 text-white py-2 px-4 rounded-md">
                    Add to Cart
                  </button>
                </div>
                <div className="mt-4">
                  <h4 className="text-sm font-medium text-gray-800 mb-2">Tasting Notes:</h4>
                  <p className="text-gray-600 text-sm">Intense floral complexity, silky texture, exceptional sweetness</p>
                </div>
              </div>
            </div>
            
            <div className="bg-white border border-gray-200 rounded-lg overflow-hidden shadow-sm">
              <div className="h-64 bg-gray-200 relative">
                <div className="absolute inset-0 bg-[url('/images/tea-pouring.jpg')] bg-cover bg-center"></div>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-2 text-gray-800">Fushoushan Oolong</h3>
                <p className="text-gray-600 mb-4">
                  From the steep slopes behind Lishan, with deep aromatics and a rich, sweet taste. Fushoushan teas are known for their exceptional balance of aromatics and flavor intensity.
                </p>
                <div className="flex justify-between items-center mb-4">
                  <div>
                    <p className="text-green-700 font-medium">$58.00</p>
                    <p className="text-gray-500 text-sm">150g / 5.3oz</p>
                  </div>
                  <button className="bg-green-700 hover:bg-green-800 text-white py-2 px-4 rounded-md">
                    Add to Cart
                  </button>
                </div>
                <div className="mt-4">
                  <h4 className="text-sm font-medium text-gray-800 mb-2">Tasting Notes:</h4>
                  <p className="text-gray-600 text-sm">Deep floral aromatics, rich sweetness, balanced complexity</p>
                </div>
              </div>
            </div>
            
            <div className="bg-white border border-gray-200 rounded-lg overflow-hidden shadow-sm">
              <div className="h-64 bg-gray-200 relative">
                <div className="absolute inset-0 bg-[url('/images/tea-plantation-landscape.jpg')] bg-cover bg-center"></div>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-2 text-gray-800">Shanlinxi Oolong</h3>
                <p className="text-gray-600 mb-4">
                  Grown in cold climate conditions, featuring a distinctive pine aroma and natural sweetness. The unique terroir of Shanlinxi, surrounded by cypress forests, imparts a distinctive character to these teas.
                </p>
                <div className="flex justify-between items-center mb-4">
                  <div>
                    <p className="text-green-700 font-medium">$42.00</p>
                    <p className="text-gray-500 text-sm">150g / 5.3oz</p>
                  </div>
                  <button className="bg-green-700 hover:bg-green-800 text-white py-2 px-4 rounded-md">
                    Add to Cart
                  </button>
                </div>
                <div className="mt-4">
                  <h4 className="text-sm font-medium text-gray-800 mb-2">Tasting Notes:</h4>
                  <p className="text-gray-600 text-sm">Pine, forest notes, floral undertones, clean sweetness</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Tea Sets */}
      <section className="py-16 bg-green-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center text-gray-800 mb-12">Tea Gift Sets</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-white border border-gray-200 rounded-lg overflow-hidden shadow-sm">
              <div className="h-64 bg-gray-200 relative">
                <div className="absolute inset-0 bg-[url('/images/tea-leaves-closeup.jpg')] bg-cover bg-center"></div>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-2 text-gray-800">High Mountain Tea Sampler Set</h3>
                <p className="text-gray-600 mb-4">
                  Experience the diversity of Taiwan's high mountain teas with this sampler set featuring 
                  Alishan, Lishan, and Shanlinxi oolongs (50g each). Perfect for those new to Taiwan teas or connoisseurs wanting to compare different terroirs.
                </p>
                <div className="flex justify-between items-center mb-4">
                  <div>
                    <p className="text-green-700 font-medium">$48.00</p>
                    <p className="text-gray-500 text-sm">150g total / 3 varieties</p>
                  </div>
                  <button className="bg-green-700 hover:bg-green-800 text-white py-2 px-4 rounded-md">
                    Add to Cart
                  </button>
                </div>
                <div className="mt-4">
                  <h4 className="text-sm font-medium text-gray-800 mb-2">Includes:</h4>
                  <ul className="text-gray-600 text-sm list-disc pl-5">
                    <li>Alishan Qing Xin Oolong (50g)</li>
                    <li>Lishan High Mountain Oolong (50g)</li>
                    <li>Shanlinxi Oolong (50g)</li>
                    <li>Brewing guide and tasting notes</li>
                  </ul>
                </div>
              </div>
            </div>
            
            <div className="bg-white border border-gray-200 rounded-lg overflow-hidden shadow-sm">
              <div className="h-64 bg-gray-200 relative">
                <div className="absolute inset-0 bg-[url('/images/tea-pouring.jpg')] bg-cover bg-center"></div>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-2 text-gray-800">Premium Gift Box</h3>
                <p className="text-gray-600 mb-4">
                  Elegant gift box containing 150g of premium Dayuling oolong tea and a handcrafted ceramic tea cup. A perfect gift for tea enthusiasts or a special treat for yourself.
                </p>
                <div className="flex justify-between items-center mb-4">
                  <div>
                    <p className="text-green-700 font-medium">$85.00</p>
                    <p className="text-gray-500 text-sm">Gift box with tea and cup</p>
                  </div>
                  <button className="bg-green-700 hover:bg-green-800 text-white py-2 px-4 rounded-md">
                    Add to Cart
                  </button>
                </div>
                <div className="mt-4">
                  <h4 className="text-sm font-medium text-gray-800 mb-2">Includes:</h4>
                  <ul className="text-gray-600 text-sm list-disc pl-5">
                    <li>Premium Dayuling Oolong (150g)</li>
                    <li>Handcrafted ceramic tea cup</li>
                    <li>Wooden gift box with satin lining</li>
                    <li>Illustrated brewing guide</li>
                    <li>Certificate of authenticity</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Brewing Accessories */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center text-gray-800 mb-12">Tea Brewing Accessories</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="bg-white border border-gray-200 rounded-lg overflow-hidden shadow-sm">
              <div className="h-48 bg-gray-200 relative">
                <div className="absolute inset-0 bg-[url('/images/tea-leaves-closeup.jpg')] bg-cover bg-center"></div>
              </div>
              <div className="p-4">
                <h3 className="text-lg font-semibold mb-2 text-gray-800">Porcelain Gaiwan</h3>
                <p className="text-gray-600 mb-3 text-sm">
                  Traditional Chinese brewing vessel, perfect for high mountain oolongs.
                </p>
                <div className="flex justify-between items-center">
                  <p className="text-green-700 font-medium">$28.00</p>
                  <button className="bg-green-700 hover:bg-green-800 text-white py-1 px-3 rounded-md text-sm">
                    Add to Cart
                  </button>
                </div>
              </div>
            </div>
            
            <div className="bg-white border border-gray-200 rounded-lg overflow-hidden shadow-sm">
              <div className="h-48 bg-gray-200 relative">
                <div className="absolute inset-0 bg-[url('/images/tea-pouring.jpg')] bg-cover bg-center"></div>
              </div>
              <div className="p-4">
                <h3 className="text-lg font-semibold mb-2 text-gray-800">Glass Teapot</h3>
                <p className="text-gray-600 mb-3 text-sm">
                  Heat-resistant glass teapot with removable infuser.
                </p>
                <div className="flex justify-between items-center">
                  <p className="text-green-700 font-medium">$32.00</p>
                  <button className="bg-green-700 hover:bg-green-800 text-white py-1 px-3 rounded-md text-sm">
                    Add to Cart
                  </button>
                </div>
              </div>
            </div>
            
            <div className="bg-white border border-gray-200 rounded-lg overflow-hidden shadow-sm">
              <div className="h-48 bg-gray-200 relative">
                <div className="absolute inset-0 bg-[url('/images/tea-plantation-landscape.jpg')] bg-cover bg-center"></div>
              </div>
              <div className="p-4">
                <h3 className="text-lg font-semibold mb-2 text-gray-800">Bamboo Tea Tray</h3>
                <p className="text-gray-600 mb-3 text-sm">
                  Traditional tea tray for gongfu style brewing.
                </p>
                <div className="flex justify-between items-center">
                  <p className="text-green-700 font-medium">$45.00</p>
                  <button className="bg-green-700 hover:bg-green-800 text-white py-1 px-3 rounded-md text-sm">
                    Add to Cart
                  </button>
                </div>
              </div>
            </div>
            
            <div className="bg-white border border-gray-200 rounded-lg overflow-hidden shadow-sm">
              <div className="h-48 bg-gray-200 relative">
                <div className="absolute inset-0 bg-[url('/images/tea-leaves-closeup.jpg')] bg-cover bg-center"></div>
              </div>
              <div className="p-4">
                <h3 className="text-lg font-semibold mb-2 text-gray-800">Ceramic Tea Cups (Set of 4)</h3>
                <p className="text-gray-600 mb-3 text-sm">
                  Handcrafted ceramic cups for serving tea.
                </p>
                <div className="flex justify-between items-center">
                  <p className="text-green-700 font-medium">$36.00</p>
                  <button className="bg-green-700 hover:bg-green-800 text-white py-1 px-3 rounded-md text-sm">
                    Add to Cart
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Shipping Information */}
      <section className="py-16 bg-green-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center text-gray-800 mb-6">Shipping & Ordering Information</h2>
          <p className="text-gray-600 text-center max-w-3xl mx-auto mb-12">
            We ship our teas worldwide to ensure tea enthusiasts everywhere can experience the exceptional quality of Taiwan high mountain teas.
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <div className="w-12 h-12 bg-primary-color rounded-full flex items-center justify-center mx-auto mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                </svg>
              </div>
              <h3 className="text-lg font-semibold mb-3 text-center">Shipping Methods</h3>
              <ul className="space-y-2 text-gray-600">
                <li className="flex items-start">
                  <span className="font-medium mr-2">Standard:</span>
                  <span>7-14 business days (free on orders over $75)</span>
                </li>
                <li className="flex items-start">
                  <span className="font-medium mr-2">Express:</span>
                  <span>3-5 business days ($15 flat rate)</span>
                </li>
                <li className="flex items-start">
                  <span className="font-medium mr-2">Priority:</span>
                  <span>1-3 business days ($25 flat rate)</span>
                </li>
              </ul>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <div className="w-12 h-12 bg-primary-color rounded-full flex items-center justify-center mx-auto mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <h3 className="text-lg font-semibold mb-3 text-center">Freshness Guarantee</h3>
              <p className="text-gray-600 mb-4">
                All our teas are vacuum-sealed immediately after processing to preserve their freshness and aroma. We import in small batches to ensure you receive the freshest tea possible.
              </p>
              <p className="text-gray-600">
                If you're not completely satisfied with your purchase, we offer a 30-day money-back guarantee.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <div className="w-12 h-12 bg-primary-color rounded-full flex items-center justify-center mx-auto mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" />
                </svg>
              </div>
              <h3 className="text-lg font-semibold mb-3 text-center">Payment Options</h3>
              <p className="text-gray-600 mb-4">
                We accept all major credit cards, PayPal, and Apple Pay for your convenience and security.
              </p>
              <p className="text-gray-600">
                All transactions are encrypted and processed through secure payment gateways to ensure your information remains safe.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
