'use client';

export default function About() {
  return (
    <div className="bg-white">
      {/* Hero Section */}
      <section className="relative h-[40vh] bg-green-50">
        <div className="absolute inset-0 bg-[url('/images/tea-plantation-landscape.jpg')] bg-cover bg-center">
          <div className="absolute inset-0 bg-black bg-opacity-40"></div>
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-full flex flex-col justify-center">
          <div className="text-center text-white">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">About Taiwan High Mountain Tea</h1>
            <p className="text-xl max-w-3xl mx-auto">
              Discover the unique characteristics and rich heritage of Taiwan's finest teas
            </p>
          </div>
        </div>
      </section>

      {/* Introduction Section */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold text-gray-800 mb-6">What is High Mountain Tea?</h2>
              <p className="text-gray-600 mb-4">
                Taiwan High Mountain Tea (高山茶) refers to teas grown at elevations above 1,000 meters (3,280 feet) in Taiwan's central mountain range. These high-altitude environments create ideal growing conditions that produce teas with exceptional flavor profiles and aromatic qualities.
              </p>
              <p className="text-gray-600 mb-4">
                The combination of cool temperatures, frequent mist, high humidity, and significant day-to-night temperature fluctuations slows the growth of tea plants, allowing them to develop more complex flavors and higher concentrations of amino acids, which contribute to the tea's sweetness and umami characteristics.
              </p>
              <p className="text-gray-600">
                High mountain teas are primarily oolong varieties, semi-oxidized teas that balance the freshness of green tea with the complexity of black tea. The most prized high mountain teas come from specific regions including Alishan, Lishan, Shanlinxi, and Dayuling, each with its own distinctive terroir and flavor profile.
              </p>
            </div>
            <div className="relative h-96 rounded-lg overflow-hidden">
              <div className="absolute inset-0 bg-[url('/images/tea-leaves-closeup.jpg')] bg-cover bg-center"></div>
            </div>
          </div>
        </div>
      </section>

      {/* Growing Regions */}
      <section className="py-16 bg-green-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center text-gray-800 mb-12">Famous Growing Regions</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h3 className="text-xl font-semibold mb-3 text-primary-color">Alishan (阿里山)</h3>
              <p className="text-gray-600 mb-4">
                Located in Chiayi County at elevations of 1,000-1,400 meters, Alishan is one of Taiwan's most famous tea regions. Alishan oolong teas are known for their floral aroma, smooth texture, and sweet aftertaste with notes of orchid and honey. The region's foggy climate and rich soil contribute to the tea's distinctive character.
              </p>
              <ul className="list-disc pl-5 text-gray-600">
                <li>Elevation: 1,000-1,400 meters</li>
                <li>Flavor profile: Floral, honey-like sweetness, orchid notes</li>
                <li>Best harvest: Spring and winter</li>
              </ul>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h3 className="text-xl font-semibold mb-3 text-primary-color">Lishan (梨山)</h3>
              <p className="text-gray-600 mb-4">
                Situated in Taichung City at elevations of 1,600-2,200 meters, Lishan produces some of Taiwan's most prestigious high mountain teas. The extreme altitude and cold climate result in slow-growing tea plants that develop exceptional complexity. Lishan oolongs are prized for their intense floral aroma, creamy texture, and long-lasting sweet finish.
              </p>
              <ul className="list-disc pl-5 text-gray-600">
                <li>Elevation: 1,600-2,200 meters</li>
                <li>Flavor profile: Complex floral notes, creamy texture, lingering sweetness</li>
                <li>Best harvest: Summer</li>
              </ul>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h3 className="text-xl font-semibold mb-3 text-primary-color">Shanlinxi (杉林溪)</h3>
              <p className="text-gray-600 mb-4">
                Located in Nantou County at elevations of 1,400-1,800 meters, Shanlinxi is known for its pristine environment surrounded by cypress forests. Teas from this region feature a distinctive pine aroma mixed with floral notes, a smooth mouthfeel, and a sweet, clean finish. The region's biodiversity contributes to the tea's unique character.
              </p>
              <ul className="list-disc pl-5 text-gray-600">
                <li>Elevation: 1,400-1,800 meters</li>
                <li>Flavor profile: Pine and floral notes, smooth texture, clean finish</li>
                <li>Best harvest: Spring</li>
              </ul>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h3 className="text-xl font-semibold mb-3 text-primary-color">Dayuling (大禹嶺)</h3>
              <p className="text-gray-600 mb-4">
                At elevations above 2,200 meters in Nantou County, Dayuling represents the highest tea-growing region in Taiwan. Due to government conservation efforts, authentic Dayuling tea is increasingly rare and commands premium prices. These teas offer exceptional complexity with intense floral aromas, a silky texture, and a remarkably long-lasting sweet aftertaste.
              </p>
              <ul className="list-disc pl-5 text-gray-600">
                <li>Elevation: Above 2,200 meters</li>
                <li>Flavor profile: Intense floral complexity, silky texture, exceptional sweetness</li>
                <li>Best harvest: Limited production</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Processing Methods */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div className="order-2 md:order-1 relative h-96 rounded-lg overflow-hidden">
              <div className="absolute inset-0 bg-[url('/images/tea-pouring.jpg')] bg-cover bg-center"></div>
            </div>
            <div className="order-1 md:order-2">
              <h2 className="text-3xl font-bold text-gray-800 mb-6">Traditional Processing</h2>
              <p className="text-gray-600 mb-4">
                Taiwan high mountain teas undergo a meticulous processing method that has been refined over generations. The process typically includes:
              </p>
              <ol className="space-y-4 text-gray-600">
                <li className="flex">
                  <span className="font-semibold mr-2">1. Plucking:</span>
                  <span>Only the tender leaves and buds are carefully hand-picked to ensure quality.</span>
                </li>
                <li className="flex">
                  <span className="font-semibold mr-2">2. Withering:</span>
                  <span>Freshly picked leaves are spread out to wilt under natural sunlight and then indoor air, reducing moisture content.</span>
                </li>
                <li className="flex">
                  <span className="font-semibold mr-2">3. Oxidation:</span>
                  <span>Leaves are gently tossed to bruise the edges, initiating the oxidation process that develops flavor complexity.</span>
                </li>
                <li className="flex">
                  <span className="font-semibold mr-2">4. Fixing:</span>
                  <span>Heat is applied to halt oxidation at precisely the right moment, typically when the leaves are 15-40% oxidized.</span>
                </li>
                <li className="flex">
                  <span className="font-semibold mr-2">5. Rolling:</span>
                  <span>Leaves are rolled to shape the tea and further release essential oils and flavors.</span>
                </li>
                <li className="flex">
                  <span className="font-semibold mr-2">6. Drying:</span>
                  <span>A final drying process stabilizes the tea for storage and develops its distinctive aroma.</span>
                </li>
              </ol>
              <p className="text-gray-600 mt-4">
                This traditional processing method, combined with the unique growing conditions of Taiwan's high mountains, creates teas with exceptional complexity, aroma, and taste that are prized by tea connoisseurs worldwide.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Brewing Guide */}
      <section className="py-16 bg-green-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center text-gray-800 mb-6">How to Brew the Perfect Cup</h2>
          <p className="text-gray-600 text-center max-w-3xl mx-auto mb-12">
            To fully appreciate the complex flavors and aromas of Taiwan high mountain tea, follow these brewing guidelines:
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <div className="w-16 h-16 bg-primary-color rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-white text-2xl font-bold">1</span>
              </div>
              <h3 className="text-xl font-semibold mb-3 text-center">Water Quality & Temperature</h3>
              <p className="text-gray-600">
                Use fresh, filtered water heated to 90-95°C (195-205°F). Water that's too hot can extract bitter compounds, while water that's too cool won't fully extract the tea's flavors.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <div className="w-16 h-16 bg-primary-color rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-white text-2xl font-bold">2</span>
              </div>
              <h3 className="text-xl font-semibold mb-3 text-center">Tea Quantity</h3>
              <p className="text-gray-600">
                Use approximately 3-5 grams of tea leaves per 150ml of water. For gongfu style brewing, use a higher ratio of tea to water (about 5-7 grams per 100ml).
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <div className="w-16 h-16 bg-primary-color rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-white text-2xl font-bold">3</span>
              </div>
              <h3 className="text-xl font-semibold mb-3 text-center">Steeping Time</h3>
              <p className="text-gray-600">
                For the first infusion, steep for 45-60 seconds. Increase steeping time by 15-30 seconds for each subsequent infusion. High mountain teas can typically be infused 5-8 times.
              </p>
            </div>
          </div>
          
          <div className="mt-12 bg-white p-6 rounded-lg shadow-sm">
            <h3 className="text-xl font-semibold mb-4 text-center">Gongfu Style Brewing (Traditional Method)</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div>
                <p className="text-gray-600 mb-4">
                  For the most authentic experience, try brewing Taiwan high mountain tea using the traditional gongfu method:
                </p>
                <ol className="space-y-2 text-gray-600">
                  <li>1. Warm your teapot or gaiwan by rinsing with hot water.</li>
                  <li>2. Add tea leaves (about 5-7g for a 100-150ml vessel).</li>
                  <li>3. Perform a quick rinse: pour hot water over the leaves and immediately discard the water.</li>
                  <li>4. For the first proper infusion, steep for 45 seconds.</li>
                  <li>5. Pour tea into a serving pitcher, then into small cups.</li>
                  <li>6. Appreciate the aroma before tasting.</li>
                  <li>7. For subsequent infusions, gradually increase steeping time.</li>
                </ol>
              </div>
              <div>
                <p className="text-gray-600 mb-4">
                  This method allows you to experience how the tea's flavor evolves through multiple infusions:
                </p>
                <ul className="space-y-2 text-gray-600">
                  <li>• 1st infusion: Light, delicate floral notes</li>
                  <li>• 2nd-3rd infusions: Fuller body, more pronounced sweetness</li>
                  <li>• 4th-5th infusions: Deep, complex flavors with lingering finish</li>
                  <li>• Later infusions: Subtle, sweet notes with mineral undertones</li>
                </ul>
                <p className="text-gray-600 mt-4">
                  The beauty of high mountain oolong lies in this journey of flavors across multiple infusions, revealing different aspects of the tea's character with each steep.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Health Benefits */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center text-gray-800 mb-6">Health Benefits</h2>
          <p className="text-gray-600 text-center max-w-3xl mx-auto mb-12">
            Beyond their exquisite taste, Taiwan high mountain teas offer numerous health benefits:
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="bg-green-50 p-6 rounded-lg">
              <h3 className="text-lg font-semibold mb-3 text-primary-color">Rich in Antioxidants</h3>
              <p className="text-gray-600">
                High mountain teas contain high levels of polyphenols and catechins that help combat free radicals and reduce oxidative stress in the body.
              </p>
            </div>
            
            <div className="bg-green-50 p-6 rounded-lg">
              <h3 className="text-lg font-semibold mb-3 text-primary-color">Heart Health</h3>
              <p className="text-gray-600">
                Regular consumption may help lower bad cholesterol levels, reduce blood pressure, and improve overall cardiovascular health.
              </p>
            </div>
            
            <div className="bg-green-50 p-6 rounded-lg">
              <h3 className="text-lg font-semibold mb-3 text-primary-color">Mental Alertness</h3>
              <p className="text-gray-600">
                Contains L-theanine which works synergistically with caffeine to provide calm alertness without the jitters associated with coffee.
              </p>
            </div>
            
            <div className="bg-green-50 p-6 rounded-lg">
              <h3 className="text-lg font-semibold mb-3 text-primary-color">Digestive Health</h3>
              <p className="text-gray-600">
                The moderate oxidation level of oolong teas can help stimulate digestion and may assist with nutrient absorption.
              </p>
            </div>
          </div>
          
          <p className="text-gray-600 text-center max-w-3xl mx-auto mt-8">
            While enjoying these potential health benefits, the primary appeal of Taiwan high mountain tea remains its exceptional taste and the mindful moment it creates in our busy lives.
          </p>
        </div>
      </section>

      {/* Our Commitment */}
      <section className="py-16 bg-primary-color text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-bold mb-6">Our Commitment to Quality</h2>
            <p className="text-lg mb-8 max-w-3xl mx-auto">
              We partner directly with small-scale farmers in Taiwan's premier tea regions to bring you authentic high mountain teas of exceptional quality. Our teas are:
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div>
                <div className="w-16 h-16 bg-white bg-opacity-20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
                <h3 className="text-xl font-semibold mb-3">Authenticity Guaranteed</h3>
                <p>
                  We verify the origin of all our teas and work only with trusted farmers who maintain traditional cultivation methods.
                </p>
              </div>
              
              <div>
                <div className="w-16 h-16 bg-white bg-opacity-20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 21a4 4 0 01-4-4V5a2 2 0 012-2h4a2 2 0 012 2v12a4 4 0 01-4 4zm0 0h12a2 2 0 002-2v-4a2 2 0 00-2-2h-2.343M11 7.343l1.657-1.657a2 2 0 012.828 0l2.829 2.829a2 2 0 010 2.828l-8.486 8.485M7 17h.01" />
                  </svg>
                </div>
                <h3 className="text-xl font-semibold mb-3">Sustainable Practices</h3>
                <p>
                  We support farmers who use environmentally responsible growing methods that protect Taiwan's precious mountain ecosystems.
                </p>
              </div>
              
              <div>
                <div className="w-16 h-16 bg-white bg-opacity-20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
                <h3 className="text-xl font-semibold mb-3">Freshness Assured</h3>
                <p>
                  We import in small batches and package our teas to preserve their delicate flavors and aromas until they reach your cup.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
