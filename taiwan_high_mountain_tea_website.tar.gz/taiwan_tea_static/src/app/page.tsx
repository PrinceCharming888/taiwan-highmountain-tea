'use client';

import Image from 'next/image';
import Link from 'next/link';

export default function Home() {
  return (
    <div className="bg-white">
      {/* Hero Section */}
      <section className="relative h-[90vh] bg-green-50">
        <div className="absolute inset-0 bg-[url('/images/tea-plantation-landscape.jpg')] bg-cover bg-center">
          <div className="absolute inset-0 bg-black bg-opacity-30"></div>
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-full flex flex-col justify-center">
          <div className="text-center text-white">
            <h1 className="text-4xl md:text-6xl font-bold mb-6">Taiwan High Mountain Tea</h1>
            <p className="text-xl md:text-2xl max-w-3xl mx-auto mb-8">
              Experience the exquisite flavor and aroma of premium Taiwanese high mountain tea
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Link href="/products" className="btn btn-primary">
                Explore Our Teas
              </Link>
              <Link href="/about" className="btn btn-outline text-white border-white hover:bg-white hover:text-primary-dark">
                Learn More
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="section-title">Why Choose Our Tea</h2>
          <p className="section-subtitle">Discover what makes Taiwan high mountain tea so special</p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center p-6 bg-green-50 rounded-lg">
              <div className="w-16 h-16 bg-primary-color rounded-full flex items-center justify-center mx-auto mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-3">Premium Quality</h3>
              <p className="text-text-light">
                Grown at elevations above 1,000 meters in pristine mountain environments, our teas develop complex flavors and aromas.
              </p>
            </div>
            
            <div className="text-center p-6 bg-green-50 rounded-lg">
              <div className="w-16 h-16 bg-primary-color rounded-full flex items-center justify-center mx-auto mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-3">Health Benefits</h3>
              <p className="text-text-light">
                Rich in antioxidants and nutrients, our teas promote wellness while providing a delightful sensory experience.
              </p>
            </div>
            
            <div className="text-center p-6 bg-green-50 rounded-lg">
              <div className="w-16 h-16 bg-primary-color rounded-full flex items-center justify-center mx-auto mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 6l3 1m0 0l-3 9a5.002 5.002 0 006.001 0M6 7l3 9M6 7l6-2m6 2l3-1m-3 1l-3 9a5.002 5.002 0 006.001 0M18 7l3 9m-3-9l-6-2m0-2v2m0 16V5m0 16H9m3 0h3" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-3">Sustainable Practices</h3>
              <p className="text-text-light">
                We partner with farmers who use traditional methods and sustainable practices to protect the environment.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-16 bg-background-light">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="section-title">Featured Teas</h2>
          <p className="section-subtitle">Explore our selection of premium Taiwan high mountain teas</p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white border border-gray-200 rounded-lg overflow-hidden shadow-sm">
              <div className="h-64 bg-gray-200 relative">
                <div className="absolute inset-0 bg-[url('/images/tea-leaves-closeup.jpg')] bg-cover bg-center"></div>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-2">Alishan Oolong Tea</h3>
                <p className="text-text-light mb-4">
                  A classic high mountain oolong with a delicate floral aroma and smooth, sweet finish.
                </p>
                <div className="flex justify-between items-center">
                  <span className="text-primary-color font-medium">$35.00</span>
                  <Link href="/products" className="btn btn-primary py-2 px-4">
                    View Details
                  </Link>
                </div>
              </div>
            </div>
            
            <div className="bg-white border border-gray-200 rounded-lg overflow-hidden shadow-sm">
              <div className="h-64 bg-gray-200 relative">
                <div className="absolute inset-0 bg-[url('/images/tea-pouring.jpg')] bg-cover bg-center"></div>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-2">Lishan High Mountain Tea</h3>
                <p className="text-text-light mb-4">
                  Premium oolong from one of Taiwan's highest tea regions with complex floral notes.
                </p>
                <div className="flex justify-between items-center">
                  <span className="text-primary-color font-medium">$45.00</span>
                  <Link href="/products" className="btn btn-primary py-2 px-4">
                    View Details
                  </Link>
                </div>
              </div>
            </div>
            
            <div className="bg-white border border-gray-200 rounded-lg overflow-hidden shadow-sm">
              <div className="h-64 bg-gray-200 relative">
                <div className="absolute inset-0 bg-[url('/images/tea-plantation-landscape.jpg')] bg-cover bg-center"></div>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-2">Dayuling Oolong Tea</h3>
                <p className="text-text-light mb-4">
                  The most prestigious Taiwanese tea, grown at elevations above 2,200 meters.
                </p>
                <div className="flex justify-between items-center">
                  <span className="text-primary-color font-medium">$65.00</span>
                  <Link href="/products" className="btn btn-primary py-2 px-4">
                    View Details
                  </Link>
                </div>
              </div>
            </div>
          </div>
          
          <div className="text-center mt-12">
            <Link href="/products" className="btn btn-primary">
              View All Products
            </Link>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="section-title">What Our Customers Say</h2>
          <p className="section-subtitle">Hear from tea enthusiasts around the world</p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-green-50 p-6 rounded-lg">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 bg-primary-color rounded-full flex items-center justify-center mr-4">
                  <span className="text-white font-bold">JD</span>
                </div>
                <div>
                  <h4 className="font-semibold">John Davis</h4>
                  <p className="text-sm text-text-light">Tea Connoisseur</p>
                </div>
              </div>
              <p className="text-text-light">
                "The Alishan Oolong is exceptional. The complex flavor profile and smooth finish make it my go-to tea for both daily enjoyment and special occasions."
              </p>
            </div>
            
            <div className="bg-green-50 p-6 rounded-lg">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 bg-primary-color rounded-full flex items-center justify-center mr-4">
                  <span className="text-white font-bold">SM</span>
                </div>
                <div>
                  <h4 className="font-semibold">Sarah Miller</h4>
                  <p className="text-sm text-text-light">Wellness Coach</p>
                </div>
              </div>
              <p className="text-text-light">
                "I've incorporated Taiwan high mountain tea into my daily wellness routine. The quality is unmatched, and I love the subtle floral notes in each cup."
              </p>
            </div>
            
            <div className="bg-green-50 p-6 rounded-lg">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 bg-primary-color rounded-full flex items-center justify-center mr-4">
                  <span className="text-white font-bold">RJ</span>
                </div>
                <div>
                  <h4 className="font-semibold">Robert Johnson</h4>
                  <p className="text-sm text-text-light">Chef</p>
                </div>
              </div>
              <p className="text-text-light">
                "As a chef, I appreciate quality ingredients. These high mountain teas have become a staple in my restaurant for their exceptional aroma and taste profile."
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Newsletter */}
      <section className="py-16 bg-primary-color text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-bold mb-4">Stay Updated</h2>
            <p className="text-lg mb-8 max-w-2xl mx-auto">
              Subscribe to our newsletter for tea tips, new product announcements, and exclusive offers.
            </p>
            <form className="max-w-md mx-auto flex flex-col sm:flex-row gap-2">
              <input
                type="email"
                placeholder="Your email address"
                className="flex-grow px-4 py-3 rounded-md text-text-dark focus:outline-none"
              />
              <button type="submit" className="bg-accent-color hover:bg-opacity-90 text-white px-6 py-3 rounded-md font-medium">
                Subscribe
              </button>
            </form>
          </div>
        </div>
      </section>
    </div>
  );
}
